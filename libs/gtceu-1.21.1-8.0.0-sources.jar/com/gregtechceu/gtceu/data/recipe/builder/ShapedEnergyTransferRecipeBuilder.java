package com.gregtechceu.gtceu.data.recipe.builder;

import com.gregtechceu.gtceu.api.recipe.ShapedEnergyTransferRecipe;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.ShapedRecipePattern;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.common.crafting.DataComponentIngredient;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.jetbrains.annotations.Nullable;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ShapedEnergyTransferRecipeBuilder {
    protected Ingredient chargeIngredient = Ingredient.EMPTY;
    protected ItemStack output = ItemStack.EMPTY;
    protected ResourceLocation id;
    protected String group = "";
    private CraftingBookCategory category = CraftingBookCategory.MISC;
    protected boolean transferMaxCharge;
    protected boolean overrideCharge;
    private final List<String> rows = Lists.newArrayList();
    private final Map<Character, Ingredient> key = Maps.newLinkedHashMap();

    public ShapedEnergyTransferRecipeBuilder(@Nullable ResourceLocation id) {
        this.id = id;
    }

    public ShapedEnergyTransferRecipeBuilder() {
        this(null);
    }

    public ShapedEnergyTransferRecipeBuilder pattern(String slice) {
        rows.add(slice);
        return this;
    }

    public ShapedEnergyTransferRecipeBuilder define(char cha, TagKey<Item> itemStack) {
        key.put(cha, Ingredient.of(itemStack));
        return this;
    }

    public ShapedEnergyTransferRecipeBuilder define(char cha, ItemStack itemStack) {
        if (!itemStack.isComponentsPatchEmpty()) {
            key.put(cha, DataComponentIngredient.of(true, itemStack));
        } else {
            key.put(cha, Ingredient.of(itemStack));
        }
        return this;
    }

    public ShapedEnergyTransferRecipeBuilder define(char cha, ItemLike itemLike) {
        key.put(cha, Ingredient.of(itemLike));
        return this;
    }

    public ShapedEnergyTransferRecipeBuilder define(char cha, Ingredient ingredient) {
        key.put(cha, ingredient);
        return this;
    }

    public ShapedEnergyTransferRecipeBuilder output(ItemStack itemStack, int count) {
        this.output = itemStack.copy();
        this.output.setCount(count);
        return this;
    }

    public ShapedEnergyTransferRecipe build() {
        return new ShapedEnergyTransferRecipe(Objects.requireNonNullElse(this.group, ""), this.category, ShapedRecipePattern.of(this.key, this.rows), this.chargeIngredient, this.overrideCharge, this.transferMaxCharge, this.output, false);
    }

    protected ResourceLocation defaultId() {
        return BuiltInRegistries.ITEM.getKey(output.getItem());
    }

    public void save(RecipeOutput consumer) {
        var recipeId = id == null ? defaultId() : id;
        consumer.accept(recipeId.withPrefix("shaped/"), build(), null);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder chargeIngredient(final Ingredient chargeIngredient) {
        this.chargeIngredient = chargeIngredient;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder output(final ItemStack output) {
        this.output = output;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder id(final ResourceLocation id) {
        this.id = id;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder group(final String group) {
        this.group = group;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder category(final CraftingBookCategory category) {
        this.category = category;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder transferMaxCharge(final boolean transferMaxCharge) {
        this.transferMaxCharge = transferMaxCharge;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ShapedEnergyTransferRecipeBuilder overrideCharge(final boolean overrideCharge) {
        this.overrideCharge = overrideCharge;
        return this;
    }
}
