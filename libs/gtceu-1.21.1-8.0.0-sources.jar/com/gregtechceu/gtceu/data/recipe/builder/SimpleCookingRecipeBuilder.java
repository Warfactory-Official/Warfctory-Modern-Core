package com.gregtechceu.gtceu.data.recipe.builder;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.recipe.ingredient.ExDataComponentIngredient;
import net.minecraft.core.component.DataComponentPredicate;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.common.crafting.DataComponentIngredient;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;

public class SimpleCookingRecipeBuilder<T extends AbstractCookingRecipe> {
    private final RecipeConstructor<T> constructor;
    protected final String folder;
    @Nullable
    protected Ingredient input;
    protected String group = "";
    protected CookingBookCategory category = CookingBookCategory.MISC;
    protected ItemStack output = ItemStack.EMPTY;
    protected float experience;
    protected int cookingTime;
    @Nullable
    protected ResourceLocation id;

    protected SimpleCookingRecipeBuilder(@Nullable ResourceLocation id, String folder, RecipeConstructor<T> constructor) {
        this.id = id;
        this.folder = folder;
        this.constructor = constructor;
    }

    public static SimpleCookingRecipeBuilder<CampfireCookingRecipe> campfireCooking(@Nullable ResourceLocation id) {
        return new SimpleCookingRecipeBuilder<>(id, "campfire_cooking", CampfireCookingRecipe::new);
    }

    public static SimpleCookingRecipeBuilder<SmeltingRecipe> smelting(@Nullable ResourceLocation id) {
        return new SimpleCookingRecipeBuilder<>(id, "smelting", SmeltingRecipe::new);
    }

    public static SimpleCookingRecipeBuilder<BlastingRecipe> blasting(@Nullable ResourceLocation id) {
        return new SimpleCookingRecipeBuilder<>(id, "blasting", BlastingRecipe::new);
    }

    public static SimpleCookingRecipeBuilder<SmokingRecipe> smoking(@Nullable ResourceLocation id) {
        return new SimpleCookingRecipeBuilder<>(id, "smoking", SmokingRecipe::new);
    }

    public SimpleCookingRecipeBuilder<T> input(TagKey<Item> tag) {
        return input(Ingredient.of(tag));
    }

    public SimpleCookingRecipeBuilder<T> input(TagKey<Item> tag, DataComponentPredicate components, boolean strict) {
        return input(ExDataComponentIngredient.of(strict, components, tag));
    }

    public SimpleCookingRecipeBuilder<T> input(ItemStack itemStack) {
        if (!itemStack.getComponentsPatch().isEmpty()) {
            input = DataComponentIngredient.of(true, itemStack);
        } else {
            input = Ingredient.of(itemStack);
        }
        return this;
    }

    public SimpleCookingRecipeBuilder<T> input(ItemLike itemLike) {
        return input(Ingredient.of(itemLike));
    }

    public SimpleCookingRecipeBuilder<T> input(Ingredient ingredient) {
        input = ingredient;
        return this;
    }

    public SimpleCookingRecipeBuilder<T> output(ItemStack itemStack) {
        this.output = itemStack.copy();
        return this;
    }

    public SimpleCookingRecipeBuilder<T> output(ItemStack itemStack, int count) {
        this.output = itemStack.copyWithCount(count);
        return this;
    }

    protected ResourceLocation defaultId() {
        return BuiltInRegistries.ITEM.getKey(output.getItem());
    }

    private T create() {
        Objects.requireNonNull(input, "Input ingredient cannot be null");
        return constructor.create(this.group, this.category, this.input, this.output, this.experience, this.cookingTime);
    }

    public void save(RecipeOutput consumer) {
        // An empty output is ItemStack.EMPTY, which ItemStack.CODEC rejects ("Value must be within range
        // [1;99]: 0; Item must not be minecraft:air"). These builders run from GTRecipes#recipeAddition
        // during the datapack reload, where callers routinely pass ChemicalHelper.get(prefix, material) —
        // empty whenever that material item was never registered — so the throw fails world loading
        // instead of dropping one recipe. Note defaultId() would NPE on an empty output anyway.
        if (output.isEmpty()) {
            GTCEu.LOGGER.error("Skipping cooking recipe {}: its result resolved to an empty stack.", id);
            return;
        }
        consumer.accept(id == null ? defaultId() : id.withPrefix(folder + "/"), create(), null);
    }


    @FunctionalInterface
    public interface RecipeConstructor<T extends AbstractCookingRecipe> {
        T create(String group, CookingBookCategory category, Ingredient ingredient, ItemStack result, float experience, int cookingTime);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public SimpleCookingRecipeBuilder<T> group(final String group) {
        this.group = group;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public SimpleCookingRecipeBuilder<T> category(final CookingBookCategory category) {
        this.category = category;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public SimpleCookingRecipeBuilder<T> experience(final float experience) {
        this.experience = experience;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public SimpleCookingRecipeBuilder<T> cookingTime(final int cookingTime) {
        this.cookingTime = cookingTime;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public SimpleCookingRecipeBuilder<T> id(@Nullable final ResourceLocation id) {
        this.id = id;
        return this;
    }
}
