package com.gregtechceu.gtceu.integration.recipeviewer;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.integration.recipeviewer.jei.GTJEIPlugin;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.EmiStack;
import mezz.jei.api.gui.drawable.IDrawable;

/**
 * Generic recipe viewer category icon.
 *
 * <p>
 * The renderable is resolved lazily, on the first {@link #get()}, and NOT in the constructor. Categories
 * are built from {@code GTRecipeCategories}' static initialiser, which {@code CommonProxy#onRegister}
 * triggers during {@code RegisterEvent} — long before JEI hands out its runtime. Resolving eagerly meant
 * {@code GTJEIPlugin.getRuntime()} was null, so the class initialiser threw, which aborted GT's own
 * onRegister partway and left later registrations (e.g. {@code gtceu:data_item}) unbound. Every consumer
 * of {@link #get()} is a recipe-viewer plugin registering its categories, which happens after the runtime
 * exists.
 */
public class CategoryIcon {

    private final ResourceLocation texture;
    private final ItemStack stack;

    private Object wrappedValue;

    public CategoryIcon(ResourceLocation texture) {
        this.texture = texture;
        this.stack = null;
    }

    public CategoryIcon(ItemStack stack) {
        this.texture = null;
        this.stack = stack;
    }

    public Object get() {
        // Deliberately re-attempts while the result is null rather than caching a "resolved" flag: a call
        // that lands before the viewer runtime is up must not poison the icon for every later call.
        if (wrappedValue == null) {
            wrappedValue = resolve();
        }
        return wrappedValue;
    }

    private Object resolve() {
        if (!GTCEu.isClientSide()) return null;
        if (GTCEu.Mods.isEMILoaded()) {
            return texture != null ? EmiCallWrapper.getRenderable(texture) : EmiCallWrapper.getRenderable(stack);
        }
        if (GTCEu.Mods.isJEILoaded()) {
            if (GTJEIPlugin.getRuntime() == null) return null;
            return texture != null ? JeiCallWrapper.getRenderable(texture) : JeiCallWrapper.getRenderable(stack);
        }
        return null;
    }

    private static class EmiCallWrapper {

        public static EmiRenderable getRenderable(ResourceLocation location) {
            return new EmiTexture(location, 0, 0, 16, 16, 16, 16, 16, 16);
        }

        public static EmiRenderable getRenderable(ItemStack stack) {
            return EmiStack.of(stack);
        }
    }

    private static class JeiCallWrapper {

        public static IDrawable getRenderable(ResourceLocation location) {
            return GTJEIPlugin.getRuntime().getJeiHelpers().getGuiHelper().drawableBuilder(location, 0, 0, 16, 16)
                    .setTextureSize(16, 16).build();
        }

        public static IDrawable getRenderable(ItemStack stack) {
            return GTJEIPlugin.getRuntime().getJeiHelpers().getGuiHelper().createDrawableItemStack(stack);
        }
    }
}
