package com.gregtechceu.gtceu.integration.map.ftbchunks;

import com.gregtechceu.gtceu.api.data.worldgen.ores.GeneratedVeinMetadata;
import com.gregtechceu.gtceu.api.item.component.prospector.ProspectorMode;
import com.gregtechceu.gtceu.integration.map.GenericMapRenderer;
import com.gregtechceu.gtceu.integration.map.ftbchunks.veins.fluid.FluidVeinIcon;
import com.gregtechceu.gtceu.integration.map.ftbchunks.veins.ore.OreVeinIcon;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import dev.ftb.mods.ftblibrary.ui.Widget;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;

public class FTBChunksRenderer extends GenericMapRenderer {
    public static final Table<ResourceKey<Level>, String, OreVeinIcon> oreElements = HashBasedTable.create();
    public static final Table<ResourceKey<Level>, ChunkPos, FluidVeinIcon> fluidElements = HashBasedTable.create();
    private static final Map<String, Widget> markers = new Object2ObjectOpenHashMap<>();

    @Override
    public boolean addMarker(Component name, String id, ResourceKey<Level> dim, ChunkPos pos, ProspectorMode.FluidInfo fluid) {
        fluidElements.put(dim, pos, new FluidVeinIcon(pos, name, fluid));
        return true;
    }

    @Override
    public boolean addMarker(Component name, ResourceKey<Level> dim, GeneratedVeinMetadata vein, String id) {
        oreElements.put(dim, id, new OreVeinIcon(name, vein));
        return true;
    }

    @Override
    public boolean removeMarker(ResourceKey<Level> dim, String id) {
        var marker = oreElements.remove(dim, id);
        return marker != null;
    }

    @Override
    public boolean doShowLayer(String name) {
        return FTBChunksOptions.showLayer(name);
    }

    @Override
    public void setLayerActive(String name, boolean active) {
        FTBChunksOptions.toggleLayer(name, active);
    }

    @Override
    public void clear() {
        oreElements.clear();
        fluidElements.clear();
    }

    public static Map<String, Widget> getMarkers() {
        return FTBChunksRenderer.markers;
    }
}
