package com.gregtechceu.gtceu.integration.kjs.builders.worldgen;

import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.worldgen.BiomeWeightModifier;
import com.gregtechceu.gtceu.api.data.worldgen.bedrockore.BedrockOreDefinition;
import com.gregtechceu.gtceu.api.data.worldgen.bedrockore.WeightedMaterial;
import net.minecraft.core.HolderSet;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import dev.latvian.mods.kubejs.registry.BuilderBase;
import java.util.*;

public class BedrockOreDefinitionBuilderJS extends BuilderBase<BedrockOreDefinition> {
    private int weight; // weight value for determining which vein will appear
    private int size; // size of the vein, in chunks.
    private IntProvider yield;// the [minimum, maximum) yields
    private int depletionAmount; // amount of fluid the vein gets drained by
    private int depletionChance = 1; // the chance [0, 100] that the vein will deplete by 1
    private int depletedYield; // yield after the vein is depleted
    private List<WeightedMaterial> materials = new ArrayList<>(); // the ores which the vein contains
    private final transient Set<ResourceKey<Level>> dimensions = new HashSet<>();
    private final List<BiomeWeightModifier> biomes = new LinkedList<>();

    public BedrockOreDefinitionBuilderJS(ResourceLocation id) {
        super(id);
    }

    public static BedrockOreDefinitionBuilderJS from(BedrockOreDefinition definition, ResourceLocation id) {
        var builder = new BedrockOreDefinitionBuilderJS(id);
        builder.weight(definition.weight());
        builder.yield(definition.yield());
        builder.depletionAmount(definition.depletionAmount());
        builder.depletionChance(definition.depletionChance());
        builder.depletedYield(definition.depletedYield());
        builder.materials(definition.materials());
        builder.dimensions.addAll(definition.dimensionFilter());
        builder.biomes.addAll(definition.getOriginalModifiers());
        return builder;
    }

    public BedrockOreDefinitionBuilderJS material(Material material, int amount) {
        this.materials.add(new WeightedMaterial(material, amount));
        return this;
    }

    public BedrockOreDefinitionBuilderJS yield(int min, int max) {
        return this.yield(UniformInt.of(min, max));
    }

    @SafeVarargs
    public final BedrockOreDefinitionBuilderJS addSpawnDimension(ResourceKey<Level>... dimensions) {
        this.dimensions.addAll(Arrays.asList(dimensions));
        return this;
    }

    public BedrockOreDefinitionBuilderJS biomes(int weight, HolderSet<Biome> biomes) {
        this.biomes.add(new BiomeWeightModifier(biomes, weight));
        return this;
    }

    @Override
    public BedrockOreDefinition createObject() {
        return new BedrockOreDefinition(weight, size, yield, depletionAmount, depletionChance, depletedYield, materials, BiomeWeightModifier.fromList(biomes), dimensions);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS weight(final int weight) {
        this.weight = weight;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS size(final int size) {
        this.size = size;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS yield(final IntProvider yield) {
        this.yield = yield;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS depletionAmount(final int depletionAmount) {
        this.depletionAmount = depletionAmount;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS depletionChance(final int depletionChance) {
        this.depletionChance = depletionChance;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS depletedYield(final int depletedYield) {
        this.depletedYield = depletedYield;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinitionBuilderJS materials(final List<WeightedMaterial> materials) {
        this.materials = materials;
        return this;
    }
}
