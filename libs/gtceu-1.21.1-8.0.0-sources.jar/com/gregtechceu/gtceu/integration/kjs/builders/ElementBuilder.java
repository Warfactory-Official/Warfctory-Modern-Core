package com.gregtechceu.gtceu.integration.kjs.builders;

import com.gregtechceu.gtceu.api.data.chemical.Element;
import com.gregtechceu.gtceu.common.data.GTElements;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import dev.latvian.mods.kubejs.registry.BuilderBase;

public class ElementBuilder extends BuilderBase<Element> {
    public final transient String name;
    public final transient ResourceLocation id;
    public transient Component translatableName;
    public transient long protons;
    public transient long neutrons;
    public transient double halfLifeSeconds = -1.0;
    public transient String decayTo;
    public transient String symbol;
    public transient boolean isIsotope;

    public ElementBuilder(ResourceLocation id) {
        super(id);
        this.id = id;
        name = id.getPath();
        translatableName = Component.translatable(id.toLanguageKey("element"));
    }

    @Override
    public Element createObject() {
        return GTElements.createAndRegister(id, protons, neutrons, halfLifeSeconds, decayTo, name, symbol, isIsotope);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder translatableName(final Component translatableName) {
        this.translatableName = translatableName;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder protons(final long protons) {
        this.protons = protons;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder neutrons(final long neutrons) {
        this.neutrons = neutrons;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder halfLifeSeconds(final double halfLifeSeconds) {
        this.halfLifeSeconds = halfLifeSeconds;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder decayTo(final String decayTo) {
        this.decayTo = decayTo;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder symbol(final String symbol) {
        this.symbol = symbol;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ElementBuilder isIsotope(final boolean isIsotope) {
        this.isIsotope = isIsotope;
        return this;
    }
}
