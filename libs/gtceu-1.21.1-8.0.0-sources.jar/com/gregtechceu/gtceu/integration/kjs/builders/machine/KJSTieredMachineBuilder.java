package com.gregtechceu.gtceu.integration.kjs.builders.machine;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.api.registry.registrate.MachineBuilder;
import com.gregtechceu.gtceu.common.data.machines.GTMachineUtils;
import com.gregtechceu.gtceu.common.mui.GTSingleblockMachinePanels;
import net.minecraft.resources.ResourceLocation;
import com.google.common.base.Preconditions;
import dev.latvian.mods.kubejs.client.LangKubeEvent;
import dev.latvian.mods.kubejs.generator.KubeAssetGenerator;
import dev.latvian.mods.kubejs.registry.BuilderBase;
import it.unimi.dsi.fastutil.ints.Int2IntFunction;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.*;
import static com.gregtechceu.gtceu.api.GTValues.*;
import static com.gregtechceu.gtceu.utils.FormattingUtil.toEnglishName;

public class KJSTieredMachineBuilder extends BuilderBase<@Nullable MachineDefinition @NotNull []> implements IMachineBuilderKJS {
    private final MachineBuilder<?, ?, ?>[] builders = new MachineBuilder[TIER_COUNT];
    public transient int[] tiers = GTMachineUtils.ELECTRIC_TIERS;
    public transient TieredCreationFunction machine;
    public transient DefinitionFunction definition = (tier, def) -> def.tier(tier);
    @Nullable
    public transient Int2IntFunction tankScalingFunction = GTMachineUtils.defaultTankSizeFunction;
    public transient boolean addDefaultTooltips = true;
    public transient boolean addDefaultModel = true;
    public transient boolean isGenerator = false;

    public KJSTieredMachineBuilder(ResourceLocation id) {
        super(id);
        this.addDefaultTooltips = false;
        this.addDefaultModel = false;
        this.dummyBuilder = true;
    }

    public KJSTieredMachineBuilder(ResourceLocation id, TieredCreationFunction machine, boolean isGenerator) {
        super(id);
        this.machine = machine;
        this.isGenerator = isGenerator;
        this.dummyBuilder = true;
    }

    @Override
    public void generateMachineModels() {
        for (int tier : this.tiers) {
            generateMachineModel(this.builders[tier], this.object[tier]);
        }
    }

    @Override
    public void generateAssets(KubeAssetGenerator generator) {
        for (int tier : this.tiers) {
            MachineDefinition definition = this.object[tier];
            if (definition == null) continue;
            final ResourceLocation id = definition.getId();
            generator.itemModel(id, gen -> gen.parent(id.withPrefix("block/machine/")));
        }
    }

    @Override
    public void generateLang(LangKubeEvent lang) {
        super.generateLang(lang);
        for (int tier : this.tiers) {
            MachineDefinition def = this.object[tier];
            if (def != null && def.getLangValue() != null) {
                lang.add(GTCEu.MOD_ID, def.getDescriptionId(), def.getLangValue());
            }
        }
    }

    @Override
    @Nullable
    public MachineDefinition @NotNull [] createObject() {
        Preconditions.checkNotNull(tiers, "Tiers can\'t be null!");
        Preconditions.checkArgument(tiers.length > 0, "tiers must have at least one tier!");
        Preconditions.checkNotNull(machine, "You must set a machine creation function! " + "example: `builder.machine((holder, tier) => new SimpleTieredMachine(holder, tier, t => t * 3200)`");
        Preconditions.checkNotNull(definition, "You must set a definition function! " + "See GTMachines for examples");
        @Nullable
        MachineDefinition @NotNull [] definitions = new MachineDefinition[TIER_COUNT];
        for (final int tier : tiers) {
            String tierName = VN[tier].toLowerCase(Locale.ROOT);
            final Int2IntFunction tankFunction = Objects.requireNonNullElse(tankScalingFunction, GTMachineUtils.defaultTankSizeFunction);
            MachineBuilder<?, ?, ?> builder = GTRegistrate.createIgnoringListenerErrors(this.id.getNamespace()).machine(String.format("%s_%s", tierName, this.id.getPath()), holder -> machine.create(holder, tier, tankFunction));
            builder.langValue("%s %s %s".formatted(VLVH[tier], toEnglishName(this.id.getPath()), VLVT[tier])).tier(tier);
            if (this.addDefaultModel) {
                builder.workableTieredHullModel(id.withPrefix("block/machines/"));
            }
            this.definition.apply(tier, builder);
            if (builder.recipeTypes().length > 0) {
                GTRecipeType recipeType = builder.recipeTypes()[0];
                if (tankScalingFunction != null && addDefaultTooltips) {
                    builder.tooltips(GTMachineUtils.workableTiered(tier, GTValues.V[tier], GTValues.V[tier] * 64, recipeType, tankScalingFunction.applyAsInt(tier), !isGenerator));
                }
            }
            if (builder.ui() == null) {
                builder.ui(GTSingleblockMachinePanels.GENERAL_MACHINE);
            }
            this.builders[tier] = builder;
            definitions[tier] = builder.register();
        }
        return definitions;
    }


    @FunctionalInterface
    public interface TieredCreationFunction {
        MetaMachine create(BlockEntityCreationInfo info, int tier, Int2IntFunction tankScaling);
    }


    @FunctionalInterface
    public interface CreationFunction<T extends MetaMachine> {
        T create(BlockEntityCreationInfo info);
    }


    @FunctionalInterface
    public interface DefinitionFunction {
        void apply(int tier, MachineBuilder<?, ?, ?> builder);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder tiers(final int[] tiers) {
        this.tiers = tiers;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder machine(final TieredCreationFunction machine) {
        this.machine = machine;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder definition(final DefinitionFunction definition) {
        this.definition = definition;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder tankScalingFunction(@Nullable final Int2IntFunction tankScalingFunction) {
        this.tankScalingFunction = tankScalingFunction;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder addDefaultTooltips(final boolean addDefaultTooltips) {
        this.addDefaultTooltips = addDefaultTooltips;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder addDefaultModel(final boolean addDefaultModel) {
        this.addDefaultModel = addDefaultModel;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMachineBuilder isGenerator(final boolean isGenerator) {
        this.isGenerator = isGenerator;
        return this;
    }
}
