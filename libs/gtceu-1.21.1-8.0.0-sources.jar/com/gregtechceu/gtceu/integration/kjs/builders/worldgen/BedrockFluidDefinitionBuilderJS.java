package com.gregtechceu.gtceu.integration.kjs.builders.worldgen;

import com.gregtechceu.gtceu.api.data.worldgen.BiomeWeightModifier;
import com.gregtechceu.gtceu.api.data.worldgen.bedrockfluid.BedrockFluidDefinition;
import net.minecraft.core.*;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.material.Fluid;
import dev.latvian.mods.kubejs.registry.BuilderBase;
import java.util.*;

public class BedrockFluidDefinitionBuilderJS extends BuilderBase<BedrockFluidDefinition> {
    private int weight; // weight value for determining which vein will appear
    private int minimumYield;
    private int maximumYield;// the [minimum, maximum) yields
    private int depletionAmount; // amount of fluid the vein gets drained by
    private int depletionChance = 1; // the chance [0, 100] that the vein will deplete by 1
    private int depletedYield; // yield after the vein is depleted
    private Fluid fluid; // the fluid which the vein contains
    private final List<BiomeWeightModifier> biomes = new LinkedList<>();
    private final transient Set<ResourceKey<Level>> dimensions = new HashSet<>();

    public BedrockFluidDefinitionBuilderJS(ResourceLocation id) {
        super(id);
    }

    public static BedrockFluidDefinitionBuilderJS from(BedrockFluidDefinition definition, ResourceLocation id) {
        var builder = new BedrockFluidDefinitionBuilderJS(id);
        builder.weight(definition.getWeight());
        builder.minimumYield(definition.getMinimumYield()).maximumYield(definition.getMaximumYield());
        builder.depletionAmount(definition.getDepletionAmount()).depletionChance(definition.getDepletionChance());
        builder.depletedYield(definition.getDepletedYield());
        builder.fluid(definition.getStoredFluid());
        builder.dimensions.addAll(definition.getDimensionFilter());
        builder.biomes.addAll(definition.getOriginalModifiers());
        return builder;
    }

    public BedrockFluidDefinitionBuilderJS yield(int min, int max) {
        return minimumYield(min).maximumYield(max);
    }

    @SafeVarargs
    public final BedrockFluidDefinitionBuilderJS addSpawnDimension(ResourceKey<Level>... dimensions) {
        this.dimensions.addAll(Arrays.asList(dimensions));
        return this;
    }

    public BedrockFluidDefinitionBuilderJS biomes(int weight, HolderSet<Biome> biomes) {
        this.biomes.add(new BiomeWeightModifier(biomes, weight));
        return this;
    }

    @Override
    public BedrockFluidDefinition createObject() {
        return new BedrockFluidDefinition(weight, minimumYield, maximumYield, depletionAmount, depletionChance, depletedYield, fluid, BiomeWeightModifier.fromList(biomes), dimensions);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS weight(final int weight) {
        this.weight = weight;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS minimumYield(final int minimumYield) {
        this.minimumYield = minimumYield;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS maximumYield(final int maximumYield) {
        this.maximumYield = maximumYield;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS depletionAmount(final int depletionAmount) {
        this.depletionAmount = depletionAmount;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS depletionChance(final int depletionChance) {
        this.depletionChance = depletionChance;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS depletedYield(final int depletedYield) {
        this.depletedYield = depletedYield;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockFluidDefinitionBuilderJS fluid(final Fluid fluid) {
        this.fluid = fluid;
        return this;
    }
}
