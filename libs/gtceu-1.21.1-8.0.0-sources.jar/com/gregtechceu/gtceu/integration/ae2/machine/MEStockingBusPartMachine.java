package com.gregtechceu.gtceu.integration.ae2.machine;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;
import com.gregtechceu.gtceu.api.sync_system.annotations.SyncToClient;
import com.gregtechceu.gtceu.config.ConfigHolder;
import com.gregtechceu.gtceu.integration.ae2.machine.feature.multiblock.IMEStockingPart;
import com.gregtechceu.gtceu.integration.ae2.slot.ExportOnlyAEItemList;
import com.gregtechceu.gtceu.integration.ae2.slot.ExportOnlyAEItemSlot;
import com.gregtechceu.gtceu.integration.ae2.slot.ExportOnlyAESlot;
import com.gregtechceu.gtceu.integration.ae2.slot.IConfigurableSlotList;
import com.gregtechceu.gtceu.utils.ExtendedUseOnContext;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import appeng.api.config.Actionable;
import appeng.api.networking.IGrid;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.api.storage.MEStorage;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import org.jetbrains.annotations.Nullable;
import java.util.Comparator;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.function.Predicate;

public class MEStockingBusPartMachine extends MEInputBusPartMachine implements IMEStockingPart {
    @SyncToClient
    @SaveField
    private boolean autoPull;
    @SaveField
    private int minStackSize = 1;
    @SaveField
    private int ticksPerCycle = 40;
    private Predicate<GenericStack> autoPullTest;

    public MEStockingBusPartMachine(BlockEntityCreationInfo info) {
        super(info, new ExportOnlyAEStockingItemList(CONFIG_SIZE));
        this.autoPullTest = $ -> false;
        setOffsetBound(ticksPerCycle);
        this.aeItemHandler = (ExportOnlyAEItemList) getInventory();
        ((ExportOnlyAEStockingItemList) getInventory()).setStockingBusPartMachine(this);
    }

    /////////////////////////////////
    // ***** Machine LifeCycle ****//
    /////////////////////////////////
    @Override
    public void addedToController(MultiblockControllerMachine controller, String name) {
        super.addedToController(controller, name);
        IMEStockingPart.super.addedToController(controller, name);
    }

    @Override
    public void removedFromController(MultiblockControllerMachine controller) {
        IMEStockingPart.super.removedFromController(controller);
        super.removedFromController(controller);
    }

    /////////////////////////////////
    // ********** Sync ME *********//
    /////////////////////////////////
    @Override
    public void autoIO() {
        super.autoIO();
        if (ticksPerCycle == 0) ticksPerCycle = ConfigHolder.INSTANCE.compat.ae2.updateIntervals; // Emergency Check to
        // Avoid Crash loops.
        if (getOffsetTimer() % ticksPerCycle == 0) {
            if (autoPull) {
                refreshList();
            }
            syncME();
        }
    }

    @Override
    protected void syncME() {
        // Update the visual display for the fake items. This also is important for the item handler's
        // getStackInSlot() method, as it uses the cached items set here.
        MEStorage networkInv = this.getMainNode().getGrid().getStorageService().getInventory();
        for (ExportOnlyAEItemSlot slot : this.aeItemHandler.getInventory()) {
            var config = slot.getConfig();
            if (config != null) {
                // Try to fill the slot
                var key = config.what();
                long extracted = networkInv.extract(key, Long.MAX_VALUE, Actionable.SIMULATE, actionSource);
                if (extracted >= minStackSize) {
                    slot.setStock(new GenericStack(key, extracted));
                    continue;
                }
            }
            slot.setStock(null);
        }
    }

    /*
     * @Override
     * public void attachSideTabs(TabsWidget sideTabs) {
     * sideTabs.setMainTab(this); // removes the cover configurator, it's pointless and clashes with layout.
     * }
     */
    @Override
    protected void flushInventory() {
        // no-op, nothing to send back to the network
    }

    @Override
    public void setDistinct(boolean isDistinct) {
        super.setDistinct(isDistinct);
        if (!isRemote() && !isDistinct) {
            // Ensure that our configured items won't match any other buses in the multiblock.
            // Needed since we allow duplicates in distinct mode on, but not off
            validateConfig();
        }
    }

    @Override
    public IConfigurableSlotList getSlotList() {
        return aeItemHandler;
    }

    @Override
    public boolean testConfiguredInOtherPart(@Nullable GenericStack config) {
        if (config == null) return false;
        // In distinct mode, we don't need to check other buses since only one bus can run a recipe at a time.
        if (!isFormed() || isDistinct()) return false;
        // Otherwise, we need to test for if the item is configured
        // in any stocking bus in the multi (besides ourselves).
        for (MultiblockControllerMachine controller : getControllers()) {
            for (MultiblockPartMachine part : controller.getParts()) {
                if (part instanceof MEStockingBusPartMachine bus) {
                    // We don't need to check for ourselves, as this case is handled elsewhere.
                    if (bus == this || bus.isDistinct()) continue;
                    if (bus.aeItemHandler.hasStackInConfig(config, false)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void setAutoPull(boolean autoPull) {
        this.autoPull = autoPull;
        if (!isRemote()) {
            syncDataHolder.markClientSyncFieldDirty("autoPull");
            if (!this.autoPull) {
                this.aeItemHandler.clearInventory(0);
            } else if (updateMEStatus()) {
                this.refreshList();
                updateInventorySubscription();
            }
        }
    }

    public void setTicksPerCycle(int ticksPerCycle) {
        this.ticksPerCycle = ticksPerCycle;
        setOffsetBound(ticksPerCycle);
    }

    /**
     * Refresh the configuration list in auto-pull mode.
     * Sets the config to the CONFIG_SIZE items with the highest amount in the ME system.
     */
    private void refreshList() {
        IGrid grid = this.getMainNode().getGrid();
        if (grid == null) {
            aeItemHandler.clearInventory(0);
            return;
        }
        MEStorage networkStorage = grid.getStorageService().getInventory();
        var counter = networkStorage.getAvailableStacks();
        // Use a PriorityQueue to sort the stacks on size, take the first CONFIG_SIZE
        // biggest stacks.
        PriorityQueue<Object2LongMap.Entry<AEKey>> topItems = new PriorityQueue<>(Comparator.comparingLong(Object2LongMap.Entry<AEKey>::getLongValue));
        for (Object2LongMap.Entry<AEKey> entry : counter) {
            long amount = entry.getLongValue();
            AEKey what = entry.getKey();
            if (amount <= 0) continue;
            if (!(what instanceof AEItemKey itemKey)) continue;
            long request = networkStorage.extract(what, amount, Actionable.SIMULATE, actionSource);
            if (request == 0) continue;
            // Ensure that it is valid to configure with this stack
            if (autoPullTest != null && !autoPullTest.test(new GenericStack(itemKey, amount))) continue;
            if (amount >= minStackSize) {
                if (topItems.size() < CONFIG_SIZE) {
                    topItems.offer(entry);
                } else if (amount > topItems.peek().getLongValue()) {
                    topItems.poll();
                    topItems.offer(entry);
                }
            }
        }
        // Now, topItems is a PQ with CONFIG_SIZE highest amount items in the system.
        int index;
        int itemAmount = topItems.size();
        for (index = 0; index < CONFIG_SIZE; index++) {
            if (topItems.isEmpty()) break;
            Object2LongMap.Entry<AEKey> entry = topItems.poll();
            AEKey what = entry.getKey();
            long amount = entry.getLongValue();
            // If we get here, the item has already been checked by the PQ.
            long request = networkStorage.extract(what, amount, Actionable.SIMULATE, actionSource);
            // Since we want our items to be displayed from highest to lowest, but poll() returns
            // the lowest first, we fill in the slots starting at itemAmount-1
            var slot = this.aeItemHandler.getInventory()[itemAmount - index - 1];
            slot.setConfig(new GenericStack(what, 1));
            slot.setStock(new GenericStack(what, request));
        }
        aeItemHandler.clearInventory(index);
    }

    @Override
    protected InteractionResult onScrewdriverClick(ExtendedUseOnContext context) {
        if (!isRemote()) {
            setAutoPull(!autoPull);
            if (autoPull) {
                context.getPlayer().sendSystemMessage(Component.translatable("gtceu.machine.me.stocking_auto_pull_enabled"));
            } else {
                context.getPlayer().sendSystemMessage(Component.translatable("gtceu.machine.me.stocking_auto_pull_disabled"));
            }
        }
        return InteractionResult.sidedSuccess(isRemote());
    }

    ////////////////////////////////
    // ****** Configuration ******//
    ////////////////////////////////
    @Override
    protected CompoundTag writeConfigToTag(HolderLookup.Provider provider) {
        if (!autoPull) {
            CompoundTag tag = super.writeConfigToTag(provider);
            tag.putBoolean("AutoPull", false);
            return tag;
        }
        // if in auto-pull, no need to write actual configured slots, but still need to write the ghost circuit
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("AutoPull", true);
        tag.putByte("GhostCircuit", (byte) circuitSlot.getCurrentCircuit());
        return tag;
    }

    @Override
    protected void readConfigFromTag(HolderLookup.Provider provider, CompoundTag tag) {
        if (tag.getBoolean("AutoPull")) {
            // if being set to auto-pull, no need to read the configured slots
            this.setAutoPull(true);
            circuitSlot.setCurrentCircuit(tag.getByte("GhostCircuit"));
            return;
        }
        // set auto pull first to avoid issues with clearing the config after reading from the data stick
        this.setAutoPull(false);
        super.readConfigFromTag(provider, tag);
    }


    private static class ExportOnlyAEStockingItemList extends ExportOnlyAEItemList {
        @Nullable
        MEStockingBusPartMachine stockingBusPartMachine;

        public ExportOnlyAEStockingItemList(int slots) {
            super(slots, ExportOnlyAEStockingItemSlot::new);
        }

        public void setStockingBusPartMachine(@Nullable MEStockingBusPartMachine stockingBusPartMachine) {
            this.stockingBusPartMachine = stockingBusPartMachine;
            for (var slot : inventory) {
                ((ExportOnlyAEStockingItemSlot) (slot)).setStockingBusPartMachine(stockingBusPartMachine);
            }
        }

        @Override
        public boolean isAutoPull() {
            return Objects.requireNonNull(getStockingBusPartMachine()).isAutoPull();
        }

        @Override
        public boolean isStocking() {
            return true;
        }

        @Override
        public boolean hasStackInConfig(GenericStack stack, boolean checkExternal) {
            boolean inThisBus = super.hasStackInConfig(stack, false);
            if (inThisBus) return true;
            if (checkExternal) {
                return Objects.requireNonNull(getStockingBusPartMachine()).testConfiguredInOtherPart(stack);
            }
            return false;
        }

        @Nullable
        public MEStockingBusPartMachine getStockingBusPartMachine() {
            return this.stockingBusPartMachine;
        }
    }


    private static class ExportOnlyAEStockingItemSlot extends ExportOnlyAEItemSlot {
        @Nullable
        MEStockingBusPartMachine stockingBusPartMachine;

        public ExportOnlyAEStockingItemSlot() {
            super();
        }

        public ExportOnlyAEStockingItemSlot(@Nullable GenericStack config, @Nullable GenericStack stock) {
            super(config, stock);
        }

        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            if (slot == 0 && this.stock != null && stockingBusPartMachine != null) {
                if (this.config != null) {
                    // Extract the items from the real net to either validate (simulate)
                    // or extract (modulate) when this is called
                    if (!stockingBusPartMachine.isOnline()) return ItemStack.EMPTY;
                    MEStorage aeNetwork = stockingBusPartMachine.getMainNode().getGrid().getStorageService().getInventory();
                    Actionable action = simulate ? Actionable.SIMULATE : Actionable.MODULATE;
                    var key = config.what();
                    long extracted = aeNetwork.extract(key, amount, action, stockingBusPartMachine.actionSource);
                    if (extracted > 0) {
                        ItemStack resultStack = key instanceof AEItemKey itemKey ? itemKey.toStack((int) extracted) : ItemStack.EMPTY;
                        if (!simulate) {
                            // may as well update the display here
                            this.stock = ExportOnlyAESlot.copy(stock, stock.amount() - extracted);
                            if (this.stock.amount() == 0) {
                                this.stock = null;
                            }
                            if (this.onContentsChanged != null) {
                                this.onContentsChanged.run();
                            }
                        }
                        return resultStack;
                    }
                }
            }
            return ItemStack.EMPTY;
        }

        @Override
        public ExportOnlyAEStockingItemSlot copy() {
            return new ExportOnlyAEStockingItemSlot(this.config == null ? null : copy(this.config), this.stock == null ? null : copy(this.stock));
        }

        @Nullable
        public MEStockingBusPartMachine getStockingBusPartMachine() {
            return this.stockingBusPartMachine;
        }

        public void setStockingBusPartMachine(@Nullable final MEStockingBusPartMachine stockingBusPartMachine) {
            this.stockingBusPartMachine = stockingBusPartMachine;
        }
    }

    public boolean isAutoPull() {
        return this.autoPull;
    }

    public int getMinStackSize() {
        return this.minStackSize;
    }

    public void setMinStackSize(final int minStackSize) {
        this.minStackSize = minStackSize;
    }

    public int getTicksPerCycle() {
        return this.ticksPerCycle;
    }

    public void setAutoPullTest(final Predicate<GenericStack> autoPullTest) {
        this.autoPullTest = autoPullTest;
    }
}
