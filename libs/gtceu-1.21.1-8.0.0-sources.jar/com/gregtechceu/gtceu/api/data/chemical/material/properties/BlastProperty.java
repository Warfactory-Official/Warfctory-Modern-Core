package com.gregtechceu.gtceu.api.data.chemical.material.properties;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.api.recipe.ingredient.SizedIngredientExtensions;
import com.gregtechceu.gtceu.common.data.GTMaterials;
import net.neoforged.neoforge.fluids.crafting.SizedFluidIngredient;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;

public class BlastProperty implements IMaterialProperty {
    /**
     * Blast Furnace Temperature of this Material.
     * If below 1000K, Primitive Blast Furnace recipes will be also added.
     * If above 1750K, a Hot Ingot and its Vacuum Freezer recipe will be also added.
     * <p>
     * If a Material with this Property has a Fluid, its temperature
     * will be set to this if it is the default Fluid temperature.
     */
    private int blastTemperature;
    /**
     * The {@link GasTier} of this Material, representing which Gas EBF recipes will be generated.
     * <p>
     * Default: null, meaning no Gas EBF recipes.
     */
    private GasTier gasTier = null;
    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getAverageMass() * blastTemperature / 50
     */
    private int durationOverride = -1;
    /**
     * The EU/t of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120.
     */
    private int EUtOverride = -1;
    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getMass() * 3
     */
    private int vacuumDurationOverride = -1;
    /**
     * The EU/t of the Vacuum Freezer recipe (if needed), overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120 EU/t.
     */
    private int vacuumEUtOverride = -1;

    public BlastProperty(int blastTemperature) {
        this.blastTemperature = blastTemperature;
    }

    public BlastProperty(int blastTemperature, GasTier gasTier) {
        this.blastTemperature = blastTemperature;
        this.gasTier = gasTier;
    }

    public BlastProperty(int blastTemperature, GasTier gasTier, int eutOverride, int durationOverride, int vacuumEUtOverride, int vacuumDurationOverride) {
        this.blastTemperature = blastTemperature;
        this.gasTier = gasTier;
        this.EUtOverride = eutOverride;
        this.durationOverride = durationOverride;
        this.vacuumEUtOverride = vacuumEUtOverride;
        this.vacuumDurationOverride = vacuumDurationOverride;
    }

    /**
     * Default property constructor.
     */
    public BlastProperty() {
        this(0);
    }

    public void setBlastTemperature(int blastTemp) {
        if (blastTemp <= 0) throw new IllegalArgumentException("Blast Temperature must be greater than zero!");
        this.blastTemperature = blastTemp;
    }

    @Override
    public void verifyProperty(MaterialProperties properties) {
        properties.ensureSet(PropertyKey.INGOT, true);
    }

    public static GasTier validateGasTier(String gasTierName) {
        if (gasTierName == null) return null;
         else if ("LOW".equalsIgnoreCase(gasTierName)) return GasTier.LOW;
         else if ("MID".equalsIgnoreCase(gasTierName)) return GasTier.MID;
         else if ("HIGH".equalsIgnoreCase(gasTierName)) return GasTier.HIGH;
         else if ("HIGHER".equalsIgnoreCase(gasTierName)) return GasTier.HIGHER;
         else if ("HIGHEST".equalsIgnoreCase(gasTierName)) return GasTier.HIGHEST;
         else {
            String message = "Gas Tier must be either \"LOW\", \"MID\", \"HIGH\", \"HIGHER\", or \"HIGHEST\"";
            throw new IllegalArgumentException("Could not find valid gas tier for name: " + gasTierName + ". " + message);
        }
    }


    public enum GasTier {
        // Tiers used by GTCEu
        LOW(() -> SizedFluidIngredient.of(GTMaterials.Nitrogen.getFluidTag(), 1000)), MID(() -> SizedFluidIngredient.of(GTMaterials.Helium.getFluidTag(), 100)), HIGH(() -> SizedFluidIngredient.of(GTMaterials.Argon.getFluidTag(), 50)), 
        // Tiers reserved for addons
        HIGHER(() -> SizedFluidIngredient.of(GTMaterials.Neon.getFluidTag(), 25)), HIGHEST(() -> SizedFluidIngredient.of(GTMaterials.Krypton.getFluidTag(), 10));
        public static final GasTier[] VALUES = values();
        private Supplier<SizedFluidIngredient> fluid;

        GasTier(Supplier<SizedFluidIngredient> fluid) {
            this.fluid = Suppliers.memoize(fluid);
        }

        public void setFluid(Supplier<SizedFluidIngredient> fluid) {
            this.fluid = Suppliers.memoize(fluid);
        }

        public SizedFluidIngredient getFluid() {
            return com.gregtechceu.gtceu.api.recipe.ingredient.SizedIngredientExtensions.copy(fluid.get());
        }

        public SizedFluidIngredient getFluid(int outputAmount) {
            return FluidRecipeCapability.CAP.copyWithModifier(fluid.get(), ContentModifier.multiplier(outputAmount));
        }
    }

    // API, need to treat all of these as used
    @SuppressWarnings("unused")
    public static class Builder {
        private int temp;
        private GasTier gasTier;
        private int eutOverride = -1;
        private int durationOverride = -1;
        private int vacuumEUtOverride = -1;
        private int vacuumDurationOverride = -1;

        public Builder() {
        }

        /**
         * Set the EBF temperature of this Material.
         * <br>
         * <br>
         * If the temperature is above <strong>1750K</strong>, it will automatically add a Vacuum Freezer recipe and Hot
         * Ingot.<br>
         * If the temperature is below <strong>1000K</strong>, it will automatically add a PBF recipe in addition to the
         * EBF recipe.
         *
         * @param temperature The temperature of the recipe in the EBF.
         */
        public Builder temp(int temperature) {
            this.temp = temperature;
            return this;
        }

        /**
         * Set the EBF temperature and gas tier of this Material.
         * <br>
         * <br>
         * If the temperature is above <strong>1750K</strong>, it will automatically add a Vacuum Freezer recipe and Hot
         * Ingot.<br>
         * If the temperature is below <strong>1000K</strong>, it will automatically add a PBF recipe in addition to the
         * EBF recipe.
         *
         * @param temperature The temperature of the recipe in the EBF.
         * @param gasTier     The {@link GasTier} of the Recipe. Will generate a second EBF recipe
         *                    using the specified gas of the tier for a speed bonus.
         */
        public Builder temp(int temperature, GasTier gasTier) {
            this.temp = temperature;
            this.gasTier = gasTier;
            return this;
        }

        /**
         * Set the EU/t of the EBF recipe for this Material.
         */
        public Builder blastStats(int eutOverride) {
            this.eutOverride = eutOverride;
            return this;
        }

        /**
         * Set the EU/t and duration of the EBF recipe for this Material.
         */
        public Builder blastStats(int eutOverride, int durationOverride) {
            this.eutOverride = eutOverride;
            this.durationOverride = durationOverride;
            return this;
        }

        /**
         * Set the EU/t of the Vacuum Freezer recipe for the Hot Ingot of this Material.
         */
        public Builder vacuumStats(int eutOverride) {
            this.vacuumEUtOverride = eutOverride;
            return this;
        }

        /**
         * Set the EU/t and duration of the Vacuum Freezer recipe for the Hot Ingot of this Material.
         */
        public Builder vacuumStats(int eutOverride, int durationOverride) {
            this.vacuumEUtOverride = eutOverride;
            this.vacuumDurationOverride = durationOverride;
            return this;
        }

        public BlastProperty build() {
            return new BlastProperty(temp, gasTier, eutOverride, durationOverride, vacuumEUtOverride, vacuumDurationOverride);
        }
    }

    /**
     * Blast Furnace Temperature of this Material.
     * If below 1000K, Primitive Blast Furnace recipes will be also added.
     * If above 1750K, a Hot Ingot and its Vacuum Freezer recipe will be also added.
     * <p>
     * If a Material with this Property has a Fluid, its temperature
     * will be set to this if it is the default Fluid temperature.
     */
    public int getBlastTemperature() {
        return this.blastTemperature;
    }

    /**
     * The {@link GasTier} of this Material, representing which Gas EBF recipes will be generated.
     * <p>
     * Default: null, meaning no Gas EBF recipes.
     */
    public void setGasTier(final GasTier gasTier) {
        this.gasTier = gasTier;
    }

    /**
     * The {@link GasTier} of this Material, representing which Gas EBF recipes will be generated.
     * <p>
     * Default: null, meaning no Gas EBF recipes.
     */
    public GasTier getGasTier() {
        return this.gasTier;
    }

    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getAverageMass() * blastTemperature / 50
     */
    public void setDurationOverride(final int durationOverride) {
        this.durationOverride = durationOverride;
    }

    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getAverageMass() * blastTemperature / 50
     */
    public int getDurationOverride() {
        return this.durationOverride;
    }

    /**
     * The EU/t of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120.
     */
    public void setEUtOverride(final int EUtOverride) {
        this.EUtOverride = EUtOverride;
    }

    /**
     * The EU/t of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120.
     */
    public int getEUtOverride() {
        return this.EUtOverride;
    }

    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getMass() * 3
     */
    public void setVacuumDurationOverride(final int vacuumDurationOverride) {
        this.vacuumDurationOverride = vacuumDurationOverride;
    }

    /**
     * The duration of the EBF recipe, overriding the stock behavior.
     * <p>
     * Default: -1, meaning the duration will be: material.getMass() * 3
     */
    public int getVacuumDurationOverride() {
        return this.vacuumDurationOverride;
    }

    /**
     * The EU/t of the Vacuum Freezer recipe (if needed), overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120 EU/t.
     */
    public void setVacuumEUtOverride(final int vacuumEUtOverride) {
        this.vacuumEUtOverride = vacuumEUtOverride;
    }

    /**
     * The EU/t of the Vacuum Freezer recipe (if needed), overriding the stock behavior.
     * <p>
     * Default: -1, meaning the EU/t will be 120 EU/t.
     */
    public int getVacuumEUtOverride() {
        return this.vacuumEUtOverride;
    }
}
